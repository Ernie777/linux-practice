#include <stdio.h>

void add(int a, int b) {
    int c = a + b;
    printf("%d + %d = %d\n", a, b, c);
}

int main() {
    int a = 3, b = 5;
    add(a, b);

    return 0;
}