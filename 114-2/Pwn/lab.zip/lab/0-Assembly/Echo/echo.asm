section .text
    global _start

_start:
    sub rsp, 0x20

    mov rax, 0
    mov rdi, 0
    mov rsi, rsp
    mov rdx, 0x1f
    syscall

    mov rax, 1
    mov rdi, 1
    mov rsi, rsp
    mov rdx, 0x1f
    syscall

    mov rax, 60
    mov rdi, 0
    syscall