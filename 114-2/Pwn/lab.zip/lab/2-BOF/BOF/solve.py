from pwn import *

context.arch = 'amd64'
context.terminal = ['tmux', 'splitw', '-h']

r = process('./bof')

payload = ???
r.sendlineafter(b'> ', payload)

r.interactive()
