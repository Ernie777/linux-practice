#include <stdio.h>
#include <stdlib.h>

void backdoor() {
    system("/bin/sh");
}

int main() {
    setvbuf(stdin, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);

    printf("Input your payload > ");

    char buf[0x20] = {0};
    read(0, buf, 0x30);

    return 0;
}