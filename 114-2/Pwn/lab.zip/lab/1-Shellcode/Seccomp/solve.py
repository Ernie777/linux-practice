from pwn import *

context.arch = 'amd64'
context.terminal = ['tmux', 'splitw', '-h']

# fd = open("./flag", 0)
# read(fd, buf, 0x100)
# write(1, buf, 0x100)
shellcode = asm("""
    ???
""")

r = process('./seccomp')

r.sendlineafter(b'> ', shellcode)

r.interactive()
