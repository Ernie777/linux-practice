#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>

int main() {
    setvbuf(stdin, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);

    char *buf = mmap(NULL, 0x1000, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (buf == MAP_FAILED) {
        printf("mmap Error\n");
        return -1;
    }

    printf("Input shellcode > ");
    read(0, buf, 0x100);

    ((void (*)(void))buf)();

    return 0;
}